﻿namespace IAD_Week4A_DanielPius_GuessingGame;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}
}


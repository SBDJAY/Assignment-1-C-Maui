﻿namespace IAD_Week4A_DanielPius_GuessingGame;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}


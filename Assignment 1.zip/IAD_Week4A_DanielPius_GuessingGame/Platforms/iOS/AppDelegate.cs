﻿using Foundation;

namespace IAD_Week4A_DanielPius_GuessingGame;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}


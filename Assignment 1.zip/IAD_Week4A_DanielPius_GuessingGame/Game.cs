﻿using System;
namespace IAD_Week4A_DanielPius_GuessingGame
{

	public enum GuessStatus
	{
		TooLow,
		TooHigh,
		Correct,
		OutOfRange
	}

	public class Game
	{
		private int _randomNumber;
		public int GuessCount;


		public Game()
		{
			// This generates a random number
			Random random = new Random();
			_randomNumber = random.Next(0, 101);
			GuessCount = 0;
		}


		public  GuessStatus CheckGuess(int guess)
		{
			GuessCount++;

			if (guess < _randomNumber)
				return GuessStatus.TooLow;
			else if (guess > _randomNumber)
				return GuessStatus.TooHigh;
			else
				return GuessStatus.Correct;

		}

	}
}

